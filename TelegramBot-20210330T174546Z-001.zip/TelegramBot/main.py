import telebot

token = open('token.txt', 'r').read()
bot = telebot.TeleBot(token)

keyboard = telebot.types.ReplyKeyboardMarkup()
keyboard.row('Привет', 'Пока')

keyboard_remove = telebot.types.ReplyKeyboardRemove()


keyboard2 = telebot.types.ReplyKeyboardMarkup()
keyboard2.row('Как дела?', 'Пока')

@bot.message_handler(commands=['start'])
def start_message(message):
    bot.send_message(message.chat.id, 'Привет', reply_markup=keyboard)



@bot.message_handler(content_types=['text'])
def start_message(message):
    if message.text.lower() == 'привет':
        bot.send_message(message.chat.id, 'Привет', reply_markup=keyboard2)

    elif message.text.lower() == 'пока':
        bot.send_message(message.chat.id, 'Пока', reply_markup=keyboard_remove)


    elif message.text.lower() == 'как дела?':
        bot.send_message(message.chat.id, 'Хорошо')

    else:
        bot.send_message(message.chat.id, 'Я тебя не понимаю')


bot.polling()